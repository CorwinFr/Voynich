# INVENTORY - RECIPE_DATASET
## Etat au 2026-04-11 (post Phase 6 : Fasciculus Medicinae + enrichissement astro-medical)

### REFERENTIELS (R01-R08)

| Fichier | Entrees | Description |
|---------|---------|-------------|
| R01_verbs.json | 79 | Verbes pharmaceutiques (+Phase 6: minuere, significare, incidere) |
| R02_ingredients.json | 405 | Ingredients (+Phase 6: +14 parties anatomiques: collum, pectus, epar, vena, sanguis...) |
| R03_units.json | 11 | Unites de mesure (drachma, uncia, scrupulus, libra...) |
| R04_forms.json | 21 | Formes galeniques (electuarium, unguentum, syrupus, oleum...) |
| R05_tools.json | 15 | Outils (+Phase 6: lanceta) |
| R06_qualities.json | 207 | Qualites galeniques + thermaux + dietetiques + humoraux (sanguineus, cholericus, phlegmaticus, melancholicus) |
| R07_plant_parts.json | 16 | Parties de plantes (radix, folia, cortex, semen, cutis...) |
| R08_indications.json | 92 | Maladies et indications (+Phase 6: febris, urina, phlebotomia, scabies) |

Total referentiels: 846 entrees

### SOURCES TOKENISEES (S01-S13)

| Fichier | Entrees | Tokens | Avec ref_id | Score | Statut |
|---------|---------|--------|-------------|-------|--------|
| S01_AN.json | 150 | 16192 | 5430 (33.5%) | 73.5 B | FAIT v4 - Antidotarium Nicolai |
| S02_CI.json | 141 | 862 | 411 (47.7%) | 87.0 A | FAIT v1 - Circa Instans (qualites galeniques) |
| S03_AUREA.json | 1 | 105 | 84 (80.0%) | 93.7 A | FAIT - Aurea Alexandrina (crib premium) |
| S04_GRABADIN.json | - | - | - | - | A FAIRE - source manquante |
| S05_MACER.json | 25 | 24148 | 3689 (15.3%) | 55.6 C | FAIT - Macer Floridus |
| S06_REGIMEN.json | 106 | 2512 | 554 (22.1%) | 62.5 C | FAIT - Regimen Sanitatis |
| S07_DALME.json | 2480 | 6367 | 1017 (16.0%) | 55.3 C | FAIT - Inventaires DALME |
| S08_AVICENNA.json | - | - | - | - | A FAIRE - OCR garbled |
| S09_COLLECTIO.json | 3680 | 274910 | 48497 (17.6%) | 53.3 C | FAIT v1 - Collectio Salernitana |
| S10_ALPHITA.json | 1714 | 74620 | 8095 (10.8%) | 52.5 C | FAIT - Alphita glossaire |
| S11_BALNEA.json | 98 | 19769 | 3143 (15.9%) | 58.6 C | FAIT v2 - De Balneis + CS balnea (Phase 6: +132 refs) |
| S12_TACUINUM.json | 58 | 18053 | 1833 (10.2%) | 52.5 C | FAIT v3 - Tacuinum Sanitatis (Phase 6: +47 refs) |
| S13_FASCICULUS.json | 48 | 2426 | 246 (10.1%) | 50.3 C | FAIT v2 - Fasciculus Medicinae 1491 (astro-medical) |

Total sources: 8501 entrees, 439964 tokens, 72999 avec ref_id (16.6%)

### COUVERTURE DES SECTIONS VMS

| Section VMS | Suffixe | Sources | Statut |
|-------------|---------|---------|--------|
| Herbal | -ol | S02_CI + S05_MACER + S10_ALPHITA | COUVERT |
| Pharma | -edy | S01_AN + S03_AUREA + S09_COLLECTIO | COUVERT |
| Balnea | -edy | S11_BALNEA (De Balneis + CS balnea) | COUVERT |
| Astro/Cosmo | mixte | S12_TACUINUM + S13_FASCICULUS (melothesia, phlebotomie, regimen mensuel) | COUVERT |
| Volvelle | logos | R03 (unites) | PARTIEL |

### TOTAL DATASET

| Metrique | Valeur |
|----------|--------|
| Fichiers referentiels | 8 |
| Fichiers sources | 11 faits / 13 |
| Entrees referentiels | 846 |
| Entrees sources | 8501 |
| Tokens total | 439964 |
| Tokens avec ref_id | 72999 (16.6%) |
| Invalid refs | 0 |
| None refs | 0 |
| Sections VMS couvertes | 4/5 (Volvelle partiel) |
| Taille totale | ~42 MB |

### HISTORIQUE DES ENRICHISSEMENTS

| Phase | Date | Actions | Impact |
|-------|------|---------|--------|
| Phase 1 | 2026-04-10 | Build R01-R08, S01, S03, S05-S07, S10 | 7 sources, 744 refs |
| Phase 2 | 2026-04-11 | Build S02_CI, S09_COLLECTIO, fix refs | +2 sources, 400K tokens |
| Phase 3 | 2026-04-11 | +27 entrees refs, re-tokenisation | +10257 tokens reclassifies, ref 14%->16.8% |
| Phase 4 | 2026-04-11 | S11_BALNEA, S12_TACUINUM, +20 entrees refs | +2 sources, couverture VMS complete |
| Phase 5 | 2026-04-11 | +30 entrees refs (aliments, thermaux, verbes), long-s S12 | +644 tokens reclassifies, S12 sort du D |
| Phase 5b | 2026-04-11 | Nettoyage OCR agressif S12 (long-s + func words) | +1436 GRAM->PREP/CONJ/COP, S12 50.2->52.3 |
| Phase 6 | 2026-04-11 | S13_FASCICULUS + 28 entrees refs astro-medical | +1 source astro, 846 refs, S11 +132 refs |

### FICHIERS MANQUANTS (non critiques)

| Code | Source | Priorite | Notes |
|------|--------|----------|-------|
| S04_GRABADIN | Liber Servitoris | BASSE | Source texte introuvable - pas bloquant |
| S08_AVICENNA | Canon Medicinae | BASSE | OCR garbled - pas bloquant |

### SCRIPTS DE BUILD

| Script | Sortie | Version |
|--------|--------|---------|
| build_all_referentiels.py | R01-R08 | v1 |
| build_S01_AN_v4.py | S01_AN.json | v4 |
| build_S02_CI.py | S02_CI.json | v1 |
| build_S03_AUREA.py | S03_AUREA.json | v1 |
| build_S05_MACER.py | S05_MACER.json | v1 |
| build_S06_REGIMEN.py | S06_REGIMEN.json | v1 |
| build_S07_DALME.py | S07_DALME.json | v1 |
| build_S09_COLLECTIO.py | S09_COLLECTIO.json | v1 |
| build_S10_ALPHITA.py | S10_ALPHITA.json | v1 |
| build_S11_BALNEA.py | S11_BALNEA.json | v1 |
| build_S12_TACUINUM.py | S12_TACUINUM.json | v1 |
| build_S13_FASCICULUS.py | S13_FASCICULUS.json | v2 |
| enrich_and_retokenize.py | Re-tokenisation Phase 3+4 | v2 |
| enrich_phase5.py | Phase 5 enrichissement alimentaire | v1 |
| enrich_phase6_astro.py | Phase 6 enrichissement astro-medical | v1 |
| clean_retokenize_S12.py | S12 nettoyage OCR Phase 5b | v1 |
| quality_scoring.py | QUALITY_SCORES.json | v4 |
| build_scoring_xlsx.py | QUALITY_SCORES.xlsx | v3 |
| fix_all_refs.py | Corrections referentiels | v1 |
